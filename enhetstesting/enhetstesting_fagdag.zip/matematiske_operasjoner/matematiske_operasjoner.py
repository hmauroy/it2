"""
Implementer funksjonene så de passer med testene.
"""


def add_and_subtract(a, b):
    """Legger sammen to tall og subtraherer det andre fra det første."""
    pass


def multiply_and_divide(a, b):
    """Multipliserer to tall og dividerer det første med det andre."""
    pass


def power_and_square_root(a, b):
    """Hever det første tallet til det andre og finner kvadratroten av det første tallet."""
    pass


def floor_and_ceil(a, b):
    """Gulv og tak av det første tallet og det andre tallet."""
    pass


def mod_and_integer_division(a, b):
    """Modulus og heltallsdivisjon av to tall."""
    pass


def average_and_sum(a, b):
    """Beregn gjennomsnitt og summen av to tall."""
    pass
